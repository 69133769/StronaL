function animation() {
  let start = Date.now();
  let logo = document.getElementById('logo');
  let windowWidth = window.innerWidth;
  let logoWidth = logo.offsetWidth;
  let targetPosition = (windowWidth - logoWidth) / 2;

  let timer = setInterval(function() {
    let timePassed = Date.now() - start;

    logo.style.left = (timePassed / 5) + 'px';

    if (timePassed > 4300) {
      clearInterval(timer);
      logo.style.left = targetPosition + 'px';
    }
  }, 20);
}